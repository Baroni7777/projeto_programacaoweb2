export const USUARIO = 'usuario';
export const PROFESSOR = 'professor';
export const CIDADE = 'cidade';
export const ALUNO = 'aluno';
export const AUTH = 'auth';
