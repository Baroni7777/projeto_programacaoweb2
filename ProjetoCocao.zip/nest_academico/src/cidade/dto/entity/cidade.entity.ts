export class Cidade {
    idCidade: number = 0;
    codCidade: string = '';
    nomeCidade: string= '';
}