
export const TabelaCidade = [
    {
        idCidade: 1,
        codCidade:'COD120',
        nomeCidade:'Birigui',
        estadoCidade:'SP'
    },
    {
        idCidade: 2,
        codCidade:'COD121',
        nomeCidade:'Aracatuba',
        estadoCidade:'SP'
    },
    {
        idCidade: 3,
        codCidade:'COD122',
        nomeCidade:'Sorocaba',
        estadoCidade:'SP'
    },
    {
        idCidade: 4,
        codCidade:'COD123',
        nomeCidade:'Campinas',
        estadoCidade:'SP'
    },
    {
        idCidade: 5,
        codCidade:'COD124',
        nomeCidade:'São Paulo',
        estadoCidade:'SP'
    },
    {
        idCidade: 6,
        codCidade:'COD125',
        nomeCidade:'Rio de Janeiro',
        estadoCidade:'RJ'
    },
]