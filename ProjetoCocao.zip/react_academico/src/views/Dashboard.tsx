export default function Dashboard() {
  return <div>Página Principal</div>;
}
