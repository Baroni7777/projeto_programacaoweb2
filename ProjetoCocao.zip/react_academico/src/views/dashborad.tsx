export default function Dashboard() {
  return  <div> <h1>Pagina Principal</h1> </div>
 
}