export interface Cidade {
  idCidade: string;
  codCidade: string;
  nomeCidade: string;
}
