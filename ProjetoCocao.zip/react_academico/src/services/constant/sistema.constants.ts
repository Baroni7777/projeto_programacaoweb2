export const REST_CONFIG = {
  BASE_URL: "http://localhost:8000/rest",
};
